﻿$ErrorActionPreference = 'Stop'
Push-Location 'C:\Projects\MindLab_Starter_Project\deploy'
try {
  Write-Host '=== Compose Services ==='
  docker compose --project-name mindlab -f .\docker-compose.yml --env-file .\.env ps

  Write-Host '
=== Probes ==='
  try { (Invoke-WebRequest -UseBasicParsing http://localhost/).StatusCode } catch { .Exception.Message }
  try { Invoke-RestMethod http://localhost/api/health } catch { .Exception.Message }
  try { Invoke-RestMethod http://localhost/api/db/health } catch { .Exception.Message }

  Write-Host '
=== Ports ==='
  Get-NetTCPConnection -State Listen | ? LocalPort -in 80,5433 | Select LocalAddress,LocalPort,OwningProcess
} finally { Pop-Location }
